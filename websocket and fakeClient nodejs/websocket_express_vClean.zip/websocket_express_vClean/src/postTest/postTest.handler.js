const express = require('express');
const router = express.Router();
const fs = require('fs');
var myEmitter = require("../../config/eventEmitter");


router.post('/', (req, res) => {
    let monJson = {
        phrase: "Vous m'envoyez un post sur postTest : \n\n",
        data: "tout plein de data"
    }
    console.log("un post sur le / de la route postTest")
    myEmitter.emit('microserviceSendMessage','postTest');    
    res.send("un post sur le / de la route postTest");
});


router.get('/', (req, res) => {
    console.log("un get sur le / de la route postTest");
    res.send("un get sur le / de la route postTest")    
});

module.exports = router;