var express = require('express');
var app = express();

app.use(express.static("./front_part"));
require('./config/routes')(app);

module.exports = app;
